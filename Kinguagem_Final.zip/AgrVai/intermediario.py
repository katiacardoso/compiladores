from infixa_posfixa import infixa_posfixa
class Intermediario:
    def __init__(self, list_tokens, list_id):
        self.lista_tokens = list_tokens
        self.lista_id = list(list_id.keys())
        self.cod_intermediario = []
        self.op_logico = ['<', '==']
        self.log_intermediario = open("log_intermediario.txt","w")

    def inicia_geracao(self):
        #Declarações de variaveis
        for id in self.lista_id:
           self.cod_intermediario.append(f'_Var {id}')
           self.log_intermediario.write(f'Declarado variavel {id}\n')
        #Gramática
        i=0
        for token in self.lista_tokens:

            if token[0] == 'leiak':
               self.cod_intermediario.append(f'leiak {self.lista_tokens[i+2][1]}')
               self.log_intermediario.write(f'Comando de leitura da variavel {self.lista_tokens[i+2][1]} \n') 
            
            elif token[0] == 'eskreva':
                self.cod_intermediario.append(f'eskreva {self.lista_tokens[i+2][1]}')
                self.log_intermediario.write(f'Comando de escrita da variavel {self.lista_tokens[i+2][1]}\n') 


            elif token[0] == '=':
                j=i+1
                atribuicao =""
                while self.lista_tokens[j][0] != ';':
                    atribuicao += " "+self.lista_tokens[j][1]
                    stack = atribuicao.split(' ')
                    j+=1
                  
                self.cod_intermediario.append(f'{self.lista_tokens[i-1][1]} = {infixa_posfixa(stack)}')     
                self.log_intermediario.write(f'Atribuido a {self.lista_tokens[i-1][1]} a expressao {infixa_posfixa(stack)}\n ') 

            elif token[0] == 'fimenkuanto':
                self.cod_intermediario.append("fimenkuanto")
                self.log_intermediario.write("Comando de repeticao `fimenkuanto` reconhecido\n ") 

                
            elif token[0] == 'enkuanto':
                j=i+1                         
                condicao = " "
                exp = ""
                
                while self.lista_tokens[j][0] != ')':                   
                    
                    if self.lista_tokens[j][0] in self.op_logico:
                        if self.lista_tokens[j-1][0] == "kid":
                            condicao+= self.lista_tokens[j-1][1] +" "+ self.lista_tokens[j][1]
                            exp= ""
                        else:    
                            condicao += infixa_posfixa(exp) + " "+self.lista_tokens[j][1]
                            exp = ""
                        j+=1

                    if self.lista_tokens[j][0] != '(' and self.lista_tokens[j][0] != ')':
                        exp += " "+self.lista_tokens[j][1]                        
                    j+=1 
                #if exp.islower(): 
                condicao += exp     
                #else: 
                #    condicao += infixa_posfixa(exp)   
                              
         
                self.cod_intermediario.append(f'enkuanto {condicao}')
                self.log_intermediario.write("Comando de repeticao `while` reconhecido\n ") 

            elif token[0] == 'sek':
                j=i+1                         
                condicao = " "
                exp = ""
                
                while self.lista_tokens[j][0] != ')':     
                    if self.lista_tokens[j][0] in self.op_logico:
                        if self.lista_tokens[j-1][0] == "kid":
                            condicao+= self.lista_tokens[j-1][1] +" "+ self.lista_tokens[j][1]
                            exp= ""
                        else:               
                            condicao += infixa_posfixa(exp) + " "+self.lista_tokens[j][1]
                            exp = ""
                        j+=1

                    if self.lista_tokens[j][0] != '(' and self.lista_tokens[j][0] != ')':
                        exp += " "+self.lista_tokens[j][1]                        
                    j+=1 
                #if exp.islower(): 
                condicao += exp     
                #else: 
                #     condicao += infixa_posfixa(exp)                 
         
                self.cod_intermediario.append(f'sek {condicao}')
                self.log_intermediario.write("Comando condicional `sek` reconhecido\n ") 

            elif token[0] == 'fimsek':
                self.cod_intermediario.append("fimsek")     
                self.log_intermediario.write("Comando fim de condicional `fimsek` reconhecido\n ") 

            elif token[0] == 'senaok':
                self.cod_intermediario.append("senaok")
                self.log_intermediario.write("Comando condicional `senaok` reconhecido\n ") 


            i+=1
        
        self.log_intermediario.close()  
        self.getIntermediario() 
       
    def getIntermediario(self):
        arquivo_intermediario = open ("arquivo_intermediario.txt","w")
        for line in self.cod_intermediario:            
            arquivo_intermediario.write(line+"\n")
        arquivo_intermediario.close()    

    def log_intermediary(self):
        log_int = open("log_intermediario.txt","r")
        for log in log_int:
            print(log)
        log_int.close()