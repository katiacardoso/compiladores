import argparse
from os import name

from lexico import Analisador_Lexico
from sintatico import Analisador_Sintatico
from semantico import Analisador_Semantico
from intermediario import Intermediario
from final import Codigo_Final


def analise_lexica(args):   
  tabela_tokens=Analisador_Lexico(args).tabela_tokens()
  return tabela_tokens


def analise_sintatica(args):
    tokens = analise_lexica(args)
    analisador_sintatico = Analisador_Sintatico(tokens)
    analisador_sintatico.verificacao_sintatica()
    return analisador_sintatico
  

def analise_semantica(args):
    tokens = analise_lexica(args)
    analise_sintatica(args)
    analisador_semantico = Analisador_Semantico(tokens)
    analisador_semantico.inicia_analise()
    return analisador_semantico 

def tabela_simbolos_semantico(args):
    analisador_semantico = analise_semantica(args)
    analisador_semantico.tabela_simbolo()
    print("Fim tabela de simbolos.....")

def cod_intermediario(args):
    tokens = analise_lexica(args)
    analise_sintatica(args)
    analisador_semantico = Analisador_Semantico(tokens)
    lista_id = analisador_semantico.inicia_analise()
    cod_intermediario = Intermediario(tokens, lista_id)
    cod_intermediario.inicia_geracao()
    return cod_intermediario

def cod_final(args, name):
    cod_intermediario(args)
    codigo_final = Codigo_Final("./arquivo_intermediario.txt",name)
    codigo_final.inicia_geracao()
    return codigo_final


def log_lexico(args):
  tabela_tokens = analise_lexica(args)
  print('*'*50)
  print('\t\t\t ANALISADOR LÉXICO \t\t\t')
  print('*'*50)
  print('[Token, Lexema, Linha, Coluna]')
  for token in range(len(tabela_tokens)):
    print(tabela_tokens[token])
  print('*Análise Léxica Concluida!')

def log_sintatico(args):
  print(" -=-"*20)
  print("\t\t\t       Análise Sintática")
  print(" -=-"*20)
  analisador_sintatico = analise_sintatica(args)
  analisador_sintatico.log_operacoes()
  print('Análise Sintática Concluida!')

def log_semantico(args):
    print(" -=-"*20)
    print("\t\t\t       Análise Semantica")
    print(" -=-"*20)
    analisador_semantico = analise_semantica(args)
    analisador_semantico.log_operacoes()
    print('Análise Semantica Concluida!')

def log_cod_intermediario(args):
    print(" -=-"*20)
    print("\t\t\t       Log Codigo Intermediario")
    print(" -=-"*20)
    cod_intermed = cod_intermediario(args)
    cod_intermed.log_intermediary()
    print("Log Intermediario Concluido!")
    print(" -=-"*20)
    print("\t\t\t       Codigo Intermediario")
    print(" -=-"*20)
    arquivo_intermediario = open("arquivo_intermediario.txt","r")
    for line in arquivo_intermediario:            
        print(line, end='')
    arquivo_intermediario.close()  
    print("Codigo Intermediario Concluído! ")  

def log_cod_final(args,name):
    print(" -=-"*20)
    print("\t\t\t       Log Codigo Final")
    print(" -=-"*20)
    codigo_final = cod_final(args, name)
    codigo_final.log_finalCode()
    print("Log Final Concluido !.....")


def log_final(args, name):
    log_cod_intermediario(args)
    log_cod_final(args,name)

def log_all(args,name):
  log_lexico(args)
  log_sintatico(args)
  log_semantico(args)
  tabela_simbolos_semantico(args)
  log_cod_intermediario(args)
  log_cod_final(args,name)

if __name__ == '__main__':

  #cria um objeto parser
  parser = argparse.ArgumentParser(prog='Compilador KINGUAGEM',description=" Compilador Mínimo Valor Produto")
  parser.add_argument('-ls', '--ls', help="Mostra o log do analisador sintático")
  parser.add_argument('-tudo', '--tudo',  nargs=2, help="Mostra todas as listagens do Compilador")
  parser.add_argument('-lt', '--lt', help="Mostra a lista de tokens do analisador lexico")
  parser.add_argument('-lse', '--lse', help="Mostra o log do analisador semantico")
  parser.add_argument('-ts', '--ts', help="Exibe a tabela de simbolos")
  parser.add_argument('-lgc', '--lgc', help="Exibe o log do codigo intermediario ")
  parser.add_argument('-code', '--code', help="Exibe o log do codigofinal ")
  parser.add_argument('-lgcF', '--lgcF', nargs=2, help="Exibe o log do codigo final ")
  #parser.add_argument('-lgc', '--lgc', nargs=2, help="Exibe o log do codigo final ")
  parser.add_argument('default', type=str, nargs='*', help="Caso nao haja nenhum argumento")
 

  args = parser.parse_args()  
  if args.tudo:
    all(args.tudo)    
  elif args.lt:
    log_lexico(args.lt)  
  elif args.ls:
     log_sintatico(args.ls)
  elif args.lse:
    log_semantico(args.lse)
  elif args.ts:
    tabela_simbolos_semantico(args.ts)
  elif args.lgc:
    log_cod_intermediario(args.lgc)
  elif args.lgcF:
    log_final(args.lgcF[0], args.lgcF[1])
  elif args.code:
    log_cod_final(args.code,name)
  elif args.default:
    log_all(args.default[0], args.default[1])