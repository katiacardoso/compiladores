import re
import os
class Codigo_Final:

    def __init__(self, cod_intermediario, name):
        self.codigo_final = []         
        self.variaveis = []
        self.addr_var = []
        self.name = name
        self.cont_label = 0
        self.label_if= 0 
        self.label_endif = 0
        self.label_else = 0
        self.stack_label = []
        self.codigo_intermediario = []
        self.log_final = open("log_final.txt","w")
        self._arquivo = open(cod_intermediario, "r")

        for line in self._arquivo:
            self.codigo_intermediario.append(line)
        self._arquivo.close()

        

    def inicia_geracao(self):
        """Variaveis"""
        self.obter_tabela_variaveis()           #Obtem as variaveis 
        self.getAddr_var()                      #Cria endereços para as variaveis
        self.log_final.write("Declaracao de variaveis realizada\n")

        self.codigo_final.append(".global main")
        self.codigo_final.append("{0}".format("main:\npush {ip, lr}"))
        self.log_final.write("Empilhamento de endereco de retorno\n")

        for line in  self.codigo_intermediario:
            print(line)
            if line.split()[0] == 'leiak':
                    self.log_final.write("Comando read executado\n")
                    self.codigo_final.append("{0}".format("LDR R0, =format2"))
                    self.codigo_final.append("{0}".format("LDR R1, ="+line.split()[1]))
                    self.codigo_final.append("BL scanf")                    
            elif line.split()[0] == 'eskreva':
                self.log_final.write("Comando print executado\n")
                self.codigo_final.append("{0}".format("LDR R0, ="+self.getAddr_var(line.split()[1:len(line.split())])))
                self.codigo_final.append("BL printf")
                    
            elif line.split()[0] == 'sek':
                self.log_final.write("Comando if executado\n")
               
                self.label_if = self.getLabel()
                self.label_else = self.getLabel() 
                self.label_endif = self.getLabel()         
                self.stack_label.append(self.label_else) #Label for endif

                exp = []

                for atr in line.split()[1:len(line.split())-1]:
                    exp.append(atr)   

                self.calc_expLogic(exp, 'sek')

                self.stack_label.append(self.label_else)
                self.codigo_final.append("{0}:".format(self.label_if))

            elif line.split()[0] == 'fimsek':
                self.log_final.write("Fim do comando if \n")

                self.codigo_final.append("{0}:".format(self.stack_label.pop()))
  
            elif  line.split()[0] == 'senaok':
                self.log_final.write("Comando else executado\n")

                self.codigo_final.append("B {0}".format(self.label_endif))
                self.codigo_final.append("{0}:".format(self.stack_label.pop()))
                self.stack_label.append(self.label_endif)                

            elif line.split()[0] == "enkuanto": 
                self.log_final.write("Comando while executado\n")

                self.label_if = self.getLabel()
                self.codigo_final.append("{0}:".format(self.label_if))
                self.label_else = self.getLabel()  
                self.stack_label.append(self.label_else) #Label for endif
                label_while = self.getLabel()
                self.stack_label.append(label_while) 
                
                exp = []
                for atr in line.split()[1:len(line.split())]:
                    exp.append(atr)                             
               
                self.calc_expLogic(exp, 'enkuanto')

                self.stack_label.append(label_while)


            elif line.split()[0] == "fimenkuanto": 
                self.log_final.write("Comando `fimenkuanto` executado\n")

                self.codigo_final.append("B {0}".format(self.label_if))
                self.codigo_final.append("{0}:".format(self.stack_label.pop()))

            elif  line.split()[1] == '=':
                self.log_final.write("Atribuicoes de variaveis executado\n")
                self.calcula_expressao(line.split(" ",2)[2].strip())
                self.codigo_final.append("pop {R1}")
                self.codigo_final.append("LDR R0, ={0}".format(line.split()[0]))
                self.codigo_final.append("STR R1, [R0]")
        
        self.codigo_final.append("pop {ip, pc}")
        self.addr_var.append(".extern printf")
        self.addr_var.append(".extern scanf")

        self.log_final.close()
        self.getFinal()          
        print("Codigo Final gerado com sucesso.")
        
        
    def getFinal(self):
        arquivo_final = open (self.name,"w")
        for line in self.codigo_final:            
            arquivo_final.write(line+"\n")
        for line in self.addr_var:            
            arquivo_final.write(line+"\n")    
        arquivo_final.close() 

    def log_finalCode(self):
        log_f = open("log_final.txt","r")
        for log in log_f:
            print(log)
        log_f.close()

    def calc_expLogic(self, exp, value):
        i=0
        expressao= ""      
        c_log = ""
        while i != len(exp):         
            
            if exp[i] == '<':                
                self.calcula_expressao(expressao)
                self.codigo_final.append("pop {R0}")        
                self.codigo_final.append("MOV R1, R0")                
                c_log = exp[i]
                expressao = ""

            elif exp[i] == "==":                
                self.calcula_expressao(expressao)
                self.codigo_final.append("pop {R0}")        
                self.codigo_final.append("MOV R1, R0")                
                c_log = exp[i]
                expressao = ""

            expressao +=" "+exp[i]                      
            i+=1

        self.calcula_expressao(expressao)
        self.codigo_final.append("pop {R0}")   
        self.codigo_final.append("MOV R2, R0")
        self.codigo_final.append("CMP R1, R2")     
        
        self.getExpBool(c_log)
 
                                                                                                                                    
    def getExpBool(self, conector):        
        if conector == "<":
            self.codigo_final.append("BGT {0}".format(self.stack_label.pop()))
        elif conector == "==":                
            self.codigo_final.append("BNE {0}".format(self.stack_label.pop()))                                


    #Metodo para obter variaveis
    def obter_tabela_variaveis(self):        
        for line in self.codigo_intermediario:                     
            if re.search("^_Var", line):               
                self.variaveis.append(line.split()[1])


    def getAddr_var(self, atr = None):
        
        #Chamado apenas uma vez no inicio, cria todos as variaveis
        if atr == None:
            self.addr_var.append(".data")
            self.addr_var.append(".balign 8")
            self.addr_var.append("format: .asciz \"%d\\n\" ")
            self.addr_var.append("format2: .asciz \"%d\" ")

            for var in self.variaveis:                
                self.addr_var.append(".balign 8")
                self.addr_var.append("{0}: .word 0".format(var.strip()))
        #caso seja uma atribuicao ja declarada
        else:
            self.calcula_expressao(atr[0])
            self.codigo_final.append("pop {R1}")
            return "format"
            
    def getLabel(self):
        self.cont_label +=1
        print("LABEL l{} gerado".format(self.cont_label))
        return "L{0}".format(self.cont_label)

    def calcula_expressao(self, expressao):        
        
        _expressao =[]
        _expressao.append(expressao)      

        if len(expressao) > 1:
            for atr in _expressao[0].split(" "): 
                
                if atr.strip().islower():
                    self.codigo_final.append("LDR R0, ={0}".format(atr.strip()))
                    self.codigo_final.append("LDR R0, [R0]")
                    self.codigo_final.append("push {R0}")
                elif atr.strip().isdigit():
                    self.codigo_final.append("MOV R0, #{0}".format(atr.strip()))
                    self.codigo_final.append("push {R0}")
                elif atr.strip() == "+":
                    self.codigo_final.append("pop {R1}")
                    self.codigo_final.append("pop {R0}")
                    self.codigo_final.append("ADD R0, R0, R1")
                    self.codigo_final.append("push {R0}")
                elif atr.strip() == "-":
                    self.codigo_final.append("pop {R1}")
                    self.codigo_final.append("pop {R0}")
                    self.codigo_final.append("SUB R0, R0, R1")
                    self.codigo_final.append("push {R0}")   
                elif atr.strip() == "*":
                    self.codigo_final.append("pop {R1}")
                    self.codigo_final.append("pop {R0}")
                    self.codigo_final.append("MUL R0, R0, R1")
                    self.codigo_final.append("push {R0}")
                elif atr.strip() == "/":   
                    self.codigo_final.append("pop {R2}")
                    self.codigo_final.append("pop {R1}")
                    self.codigo_final.append("MOV R0, #0")
                    self.codigo_final.append("_division:")
                    self.codigo_final.append("SUBS R1, R1, R2")
                    self.codigo_final.append("ADD R0, R0,#1")
                    self.codigo_final.append("BHI _division")
                    self.codigo_final.append("push {R0}")
        else:
            if expressao.isdigit():           
                self.codigo_final.append("MOV R0, #{0}".format(expressao))              
                self.codigo_final.append("push {R0}")

            else:
                self.codigo_final.append("LDR R0, ={0}".format(expressao))
                self.codigo_final.append("LDR R0, [R0]")
                self.codigo_final.append("push {R0}")